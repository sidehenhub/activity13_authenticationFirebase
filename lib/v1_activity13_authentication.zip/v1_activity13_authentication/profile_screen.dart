import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:authentication_app/main.dart'; // Import main.dart to access MyHomePage (login screen)

class ProfileScreen extends StatefulWidget {
  @override
  _ProfileScreenState createState() => _ProfileScreenState();
}

class _ProfileScreenState extends State<ProfileScreen> {
  final FirebaseAuth _auth = FirebaseAuth.instance;
  final TextEditingController _newPasswordController = TextEditingController();
  final TextEditingController _currentPasswordController = TextEditingController();
  final GlobalKey<FormState> _passwordFormKey = GlobalKey<FormState>();
  String? _errorMessage;

  // Sign out method
  Future<void> _signOut(BuildContext context) async {
    await _auth.signOut();
    Navigator.of(context).pushReplacement(
      MaterialPageRoute(builder: (context) => MyHomePage(title: 'Firebase Auth Demo')),
    ); // Navigate back to the login screen
  }

  // Change password method
  Future<void> _changePassword(BuildContext context) async {
    try {
      User? user = _auth.currentUser;
      if (user != null && _passwordFormKey.currentState!.validate()) {
        // Reauthenticate user before allowing password change
        String currentPassword = _currentPasswordController.text;
        String newPassword = _newPasswordController.text;

        AuthCredential credential = EmailAuthProvider.credential(
          email: user.email!,
          password: currentPassword,
        );

        // Reauthenticate the user
        await user.reauthenticateWithCredential(credential);

        // Change password
        await user.updatePassword(newPassword);
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(
          content: Text("Password changed successfully."),
        ));
      }
    } catch (e) {
      setState(() {
        _errorMessage = "Failed to change password: ${e.toString()}";
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    User? user = _auth.currentUser;  // Get the current logged-in user

    return Scaffold(
      appBar: AppBar(
        title: Text("Profile"),
        actions: <Widget>[
          IconButton(
            icon: Icon(Icons.exit_to_app), // Logout icon
            onPressed: () => _signOut(context), // Sign out the user when pressed
          ),
        ],
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            crossAxisAlignment: CrossAxisAlignment.center,
            children: <Widget>[
              user != null
                  ? Column(
                      children: [
                        Text(
                          "Welcome, ${user.email}",
                          style: TextStyle(
                            fontSize: 24,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                        SizedBox(height: 16),
                        Text(
                          "Email: ${user.email}",
                          style: TextStyle(fontSize: 18),
                        ),
                      ],
                    )
                  : CircularProgressIndicator(),
              SizedBox(height: 32),

              // Password change form
              _buildChangePasswordForm(),

              // Logout button
              SizedBox(height: 32),
              ElevatedButton(
                onPressed: () => _signOut(context), // Sign out when pressed
                child: Text("Logout"),
              ),
            ],
          ),
        ),
      ),
    );
  }

  // Change password form widget
  Widget _buildChangePasswordForm() {
    return Form(
      key: _passwordFormKey,
      child: Column(
        children: [
          TextFormField(
            controller: _currentPasswordController,
            decoration: InputDecoration(labelText: 'Current Password'),
            obscureText: true,
            validator: (value) {
              if (value?.isEmpty ?? true) {
                return 'Please enter your current password';
              }
              return null;
            },
          ),
          TextFormField(
            controller: _newPasswordController,
            decoration: InputDecoration(labelText: 'New Password'),
            obscureText: true,
            validator: (value) {
              if (value?.isEmpty ?? true) {
                return 'Please enter a new password';
              }
              if ((value?.length ?? 0) < 6) {
                return 'Password should be at least 6 characters';
              }
              return null;
            },
          ),
          SizedBox(height: 16),
          ElevatedButton(
            onPressed: () => _changePassword(context),
            child: Text('Change Password'),
          ),
          SizedBox(height: 16),
          if (_errorMessage != null)
            Text(
              _errorMessage!,
              style: TextStyle(color: Colors.red),
            ),
        ],
      ),
    );
  }
}
